/**
 * @author Alex J. Strubbe
 *
 * @file functions.c
 * @brief Functions for monitoring and managing the imu_driver process.
 *
 * This file contains implementations for functions that check if the
 * imu_driver process is running, handle timer signals, and restart
 * the imu_driver process if it is not running.
 * It utilizes POSIX threads for concurrent execution of the restart
 * logic.
 */

#include "functions.h"

#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <unistd.h>

const char *process_name = "imu_driver";  ///< Name of the process to monitor
pthread_t restarter;  ///< Thread handle for restarting the imu_driver process

/**
 * @brief Timer signal handler implementation.
 *
 * This function is called when the timer expires, and it triggers
 * the check for the imu_driver process.
 *
 * @param signum The signal number received.
 */
void TimerHandler(int signum) {
  // Call the function to restart imu_driver if necessary
  printf("Timer triggered. Checking process...\n");
  ImuChecker();
}

/**
 * @brief Retrieves the PID of a process by its name.
 *
 * This function executes a shell command to find the PID of the
 * process with the specified name.
 *
 * @param process_name The name of the process to search for.
 * @return int The PID of the process, or -1 if the process is not found.
 */
int GetPidByName(const char *process_name) {
  char command[256];
  snprintf(command, sizeof(command), "pgrep -x %s", process_name);
  FILE *fp = popen(command, "r");
  if (fp == NULL) {
    perror("popen");
    return -1;
  }
  int pid = -1;
  if (fscanf(fp, "%d", &pid) == 1) {
    // Successfully retrieved a PID
  }
  pclose(fp);
  return pid;
}

/**
 * @brief Checks if the imu_driver process is running.
 *
 * If the imu_driver is not running, this function creates a thread
 * to restart it.
 */
void ImuChecker() {
  int imu_driver_pid = GetPidByName(process_name);
  printf("%d\n", imu_driver_pid);
  if (imu_driver_pid == -1) {
    printf("imu_driver not running. Attempting to restart...\n");
    if (pthread_create(&restarter, NULL, Restarter, NULL) != 0) {
      perror("pthread_create failed");
    }
    // Detach the thread so it runs independently
    pthread_detach(restarter);
  }
}

/**
 * @brief Restarts the imu_driver process.
 *
 * This function is executed in a new thread, forking a child process
 * to execute the imu_driver binary.
 *
 * @note * This was one of the only ways I could figure out how to make the
 * program work without needing to wait for the child to die directly in the
 * same thread.
 *
 * @return void* Returns NULL upon completion.
 */
void *Restarter(void *param) {
  pid_t pid = fork();

  if (pid == 0) {
    // Child process: re-start imu_driver
    char *argument_list[] = {"./imu_driver", NULL};
    execve("./imu_driver", argument_list, NULL);
  }
  if (pid > 0) {
    int status;
    waitpid(pid, &status, 0);
  }

  return NULL;
}
