/**
 * @author Alex J. Strubbe
 *
 * @file main.c
 * @brief Main entry point for monitoring the imu_driver process.
 *
 * This file sets up a POSIX timer that periodically checks if the
 * imu_driver process is running by sending a SIGUSR1 signal. If the
 * process is not running, it triggers a restart.
 */

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#include "functions.h"

/**
 * @brief Main function that sets up a timer and installs a signal handler to
 * check the `imu_driver` process.
 *
 * This program creates a POSIX timer that periodically sends a SIGUSR1 signal.
 * When the signal is received, the `TimerHandler` function is invoked to check
 * if the `imu_driver` is running, and restart it if necessary.
 *
 * @return int Returns 0 on successful execution.
 */
int main() {
  struct sigaction
      action;  ///< Sigaction structure to define signal handling behavior
  struct sigevent sev;      ///< Structure to configure timer notifications
  __timer_t timer_id;       ///< Timer ID for the created POSIX timer
  struct itimerspec timer;  ///< Timer specification structure for interval and
                            ///< initial expiration time

  // Install TimerHandler as the signal handler for SIGUSR1
  action.sa_handler = &TimerHandler;
  action.sa_flags = SA_RESTART;
  sigaction(SIGUSR1, &action, NULL);

  // Configure the timer to send SIGUSR1 on expiration
  sev.sigev_notify = SIGEV_SIGNAL;        // Notify using signal
  sev.sigev_signo = SIGUSR1;              // Send SIGUSR1 when timer expires
  sev.sigev_value.sival_ptr = &timer_id;  // Pass the timer ID to the handler

  // Create the POSIX timer
  timer_create(CLOCK_REALTIME, &sev, &timer_id);

  // Configure the timer to expire after 1.5 seconds and repeat every 1.5
  // seconds
  timer.it_value.tv_sec = 1;           // Initial delay of 1 second
  timer.it_value.tv_nsec = 500000000;  // 500 million nanoseconds = 0.5 seconds
  timer.it_interval.tv_sec = 1;        // Repeat every 1.5 seconds
  timer.it_interval.tv_nsec = 500000000;

  // Start the POSIX timer
  timer_settime(timer_id, 0, &timer, NULL);

  // Infinite loop to keep the program running
  while (1) {
    usleep(100000);  // Sleep for 100ms to reduce CPU usage
  }

  return 0;
}
