/**
 * @author Alex J. Strubbe
 *
 * @file functions.h
 * @brief Functions for monitoring and managing the imu_driver process.
 *
 * This file contains declarations for functions that check if the
 * imu_driver process is running, handle timer signals, and restart
 * the imu_driver process if it is not running.
 * It utilizes POSIX threads for concurrent execution of the restart
 * logic.
 */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

/**
 * @brief Retrieves the PID of a process by its name.
 *
 * This function uses the `pgrep` command to search for the specified
 * process name and returns its PID.
 *
 * Code provided by the professor.
 *
 * @param process_name The name of the process to search for.
 * @return int The PID of the process, or -1 if the process is not found.
 */
int GetPidByName(const char *process_name);

/**
 * @brief Timer signal handler function.
 *
 * This function is called when the timer expires. It checks if the
 * `imu_driver` process is running and restarts it if necessary.
 *
 * @param signum The signal number received.
 */
void TimerHandler(int signum);

/**
 * @brief Checks if the `imu_driver` process is running.
 *
 * This function retrieves the PID of the `imu_driver` process and
 * attempts to restart it if it's not running.
 */
void ImuChecker();

/**
 * @brief Restarts the `imu_driver` process.
 *
 * This function creates a new thread that forks a child process to
 * restart the `imu_driver`.
 *
 * @return void* Returns NULL upon completion.
 */
void *Restarter();

#endif
