/**
 * @author Alex J. Strubbe
 *
 * @file functions.c
 * @brief Functions for handling IMU driver behavior and file operations.
 *
 * This file contains implementations for managing the IMU driver,
 * handling timer signals, and writing sensor data
 * to a specified file.
 */

#include "functions.h"

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#define FILE_NAME "imu_data.txt"

FILE *file;              ///< File pointer for storing IMU data
float elapsed_time = 0;  ///< Elapsed time since the start of the program
float p_x = 20;          ///< Current x position of the robot
float p_y = 10;          ///< Current y position of the robot
float v_x = 0;           ///< Current x velocity of the robot
float v_y = 0;           ///< Current y velocity of the robot
float acc_x = 0.15;      ///< Constant x-axis acceleration
float acc_y = 0.06;      ///< Constant y-axis acceleration

struct timespec prev_time = {
    0, 0};  ///< Holds the previous timestamp for delta time calculation

/**
 * @brief Handles the timer signal to periodically update IMU data.
 *
 * This function is called every 200ms when the POSIX timer sends the `SIGALRM`
 * signal. It triggers the `ImuDriver` function to update the robot's state and
 * write the new data to the file.
 *
 * @param signum Signal number (unused in this function).
 */
void TimerHandler(int signum) { ImuDriver(); }

/**
 * @brief Handles termination signals to close the file and exit safely.
 *
 * This function is invoked when the program receives either `SIGTERM` or
 * `SIGINT`. It closes the IMU data file and ensures the program exits
 * gracefully.
 *
 * @param signal The signal number received (`SIGTERM` or `SIGINT`).
 */
void SignalHandler(int signal) {
  if (signal == SIGTERM || signal == SIGINT) {
    printf("\nProgram Interrupted. Exiting driver.\n");
    if (file != NULL) {
      fclose(file);  ///< Close the file before exiting
      exit(1);       ///< Terminate the program
    }
  }
}

/**
 * @brief Creates or resumes the IMU data file.
 *
 * This function creates the `imu_data.txt` file if it doesn't exist, or resumes
 * writing to it if it already contains data. When resuming, it reads the last
 * line to restore the robot's previous state (position, velocity, and
 * acceleration).
 */
void CreateFile() {
  char buffer[1024];
  long file_size = 0;
  file =
      fopen(FILE_NAME, "a+");  ///< Open or create the file for appending data

  // Check if the file opened successfully
  if (file == NULL) {
    perror("Failed to open file");
    exit(EXIT_FAILURE);
  }

  // Get file size to check if it's new or resuming
  fseek(file, 0, SEEK_END);  ///< Move to the end of the file
  file_size = ftell(file);   ///< Get the file size
  rewind(file);              ///< Return to the beginning of the file

  // Read the last line if the file isn't empty to resume from the last state
  if (file_size == 0 || fgets(buffer, sizeof(buffer), file) == NULL) {
    printf("Starting IMU_Driver...\n\n\n");
  } else {
    printf("Resuming IMU_Driver...\n\n\n");
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
      sscanf(buffer, "%f , %f , %f , %f , %f , %f , %f", &elapsed_time, &p_x,
             &p_y, &v_x, &v_y, &acc_x, &acc_y);
    }
    // fprintf(file, "Resuming from previous state.\n"); ///< Notifies in the
    // file when an interruption was encountered. (Uncomment this line for
    // checking where the file was resumed at [this is more for debugging])
  }
}

/**
 * @brief Updates the robot's state and writes the data to the file.
 *
 * This function calculates the robot's new velocity and position based on its
 * acceleration and the elapsed time since the last update. It writes the
 * updated data to the `imu_data.txt` file in the format: Time, p_x, p_y, v_x,
 * v_y, acc_x, acc_y
 *
 * The velocity and position are updated using basic motion formulas:
 * - `v_x = v_x + acc_x * delta_time`
 * - `p_x = p_x + v_x * delta_time`
 * - Similar calculations for the y-axis.
 */
void ImuDriver() {
  struct timespec current_time;
  float delta_time;

  // Get the current time
  clock_gettime(CLOCK_REALTIME, &current_time);

  // Calculate delta time in seconds
  if (prev_time.tv_sec == 0 && prev_time.tv_nsec == 0) {
    delta_time = 0;  ///< No delta time for the first iteration (This also
                     ///< reserves the previous value from the resummed file)
  } else {
    delta_time = (current_time.tv_sec - prev_time.tv_sec) +
                 (current_time.tv_nsec - prev_time.tv_nsec) / 1e9;
  }

  // Update previous time to current for the next iteration
  prev_time = current_time;

  // Update velocity and position using delta time
  v_x = v_x + acc_x * delta_time;
  v_y = v_y + acc_y * delta_time;
  p_x = p_x + v_x * delta_time;
  p_y = p_y + v_y * delta_time;
  elapsed_time += delta_time;

  // Write the updated state to the file
  fprintf(file, "%.2f , %.4f, %.4f, %.4f, %.4f, %.4f, %.4f\n", elapsed_time,
          p_x, p_y, v_x, v_y, acc_x, acc_y);
  fflush(file);  ///< Ensure the data is written to disk immediately
}
