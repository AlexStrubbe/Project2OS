/**
 * @author Alex J. Strubbe
 *
 * @file main.c
 * @brief Main entry point for the IMU driver program.
 *
 * This program sets up a timer that periodically triggers the IMU
 * driver to log sensor data. It also handles signals for graceful
 * termination of the process.
 */

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#include "functions.h"

/**
 * @brief Main entry point for the IMU driver program.
 *
 * This program initializes the signal handling, creates a timer that triggers
 * every 200ms to update the IMU data, and enters an infinite loop to wait for
 * signals. The program also prints its process ID (PID) for reference.
 *
 * @return int Exit status of the program (0 on success).
 */
int main() {
  struct sigaction action;  ///< Structure for handling signals
  struct sigaction sa;      ///< New sigaction for signal handling
  struct sigevent sev;      ///< Structure for timer event notification
  timer_t timer_id;         ///< Timer ID for the POSIX timer
  struct itimerspec
      timer;  ///< Timer specification for initial and interval settings

  // Install TimerHandler as the signal handler for SIGALRM
  action.sa_handler =
      &TimerHandler;  ///< Set TimerHandler function to handle SIGALRM
  action.sa_flags = SA_RESTART;       ///< Restart interrupted system calls
  sigaction(SIGALRM, &action, NULL);  ///< Register the signal handler

  // Configure the timer to send SIGALRM on expiration
  sev.sigev_notify = SIGEV_SIGNAL;  ///< Notify using signal
  sev.sigev_signo = SIGALRM;        ///< Send SIGALRM when the timer expires
  sev.sigev_value.sival_ptr = &timer_id;  // Pass the timer ID to the handler

  // Create the POSIX timer
  timer_create(CLOCK_REALTIME, &sev, &timer_id);  ///< Create a new timer

  // Configure the timer to expire after 0.2 seconds and repeat every 0.2
  // seconds
  timer.it_value.tv_sec = 0;  ///< Initial expiration after 0 seconds
  timer.it_value.tv_nsec =
      200000000;                 ///< 200 million nanoseconds = 0.2 seconds
  timer.it_interval.tv_sec = 0;  ///< Interval expiration after 0 seconds
  timer.it_interval.tv_nsec = 200000000;  ///< Repeat every 0.2 seconds

  CreateFile();  ///< Create or resume the IMU data file

  // Start the POSIX timer
  timer_settime(timer_id, 0, &timer,
                NULL);  ///< Start the timer with specified settings

  // Setup signal handling for SIGINT and SIGTERM
  sa.sa_handler =
      SignalHandler;  ///< Set the signal handler for termination signals

  sigaction(SIGINT, &sa, NULL);   ///< Register handler for SIGINT
  sigaction(SIGTERM, &sa, NULL);  ///< Register handler for SIGTERM

  printf("The PID of this program is: %d\n",
         getpid());  ///< Print the program's PID

  while (1) {
    pause();  // Wait for signals
  }
  return 0;  // Return success
}
