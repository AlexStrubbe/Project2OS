/**
 * @author Alex J. Strubbe
 *
 * @file functions.h
 * @brief Functions for handling IMU driver behavior and file operations.
 *
 * This file contains declarations for managing the IMU driver,
 * handling timer signals, and writing sensor data
 * to a specified file.
 */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#define FILE_NAME "imu_data.txt"  ///< Define the file name constant
/**
 * @brief Signal handler for termination signals (SIGTERM, SIGINT).
 *
 * This function handles cleanup and termination of the program when
 * it receives a signal to terminate. It ensures the data file is closed
 * before exiting the program.
 *
 * @param signal The signal number received.
 */
void SignalHandler(int signal);

/**
 * @brief Timer handler for the POSIX timer.
 *
 * This function is called when the timer expires. It triggers the
 * IMU data update process by calling the ImuDriver function.
 *
 * @param signum The signal number received (should be SIGALRM).
 */
void TimerHandler(int signum);

/**
 * @brief Creates and initializes the IMU data file.
 *
 * This function attempts to open the file named "imu_data.txt" for
 * appending data. If the file does not exist, it creates a new one.
 * It also reads the last entry from the file if it exists to resume
 * the IMU driver's state.
 */
void CreateFile();

/**
 * @brief Updates and writes IMU data to the file.
 *
 * This function calculates the new position and velocity of the robot
 * based on the current accelerations and time delta. It formats the
 * data and writes a new line to the IMU data file.
 */
void ImuDriver();

#endif
